# Installation — skill `horror-beatsync-video`

Merci pour ton achat. Ce dossier est un **skill Claude Code** : une fois posé au bon
endroit, Claude le charge tout seul dès que ta demande parle de beat-sync, de horror
mix, ou de « cale la vidéo sur le drop ».

## 1. Copier le dossier

**Pour un seul projet** (le skill n'existe que dans ce dépôt) :

```bash
mkdir -p .claude/skills
cp -r horror-beatsync-video .claude/skills/
```

**Pour tous tes projets** (le skill est disponible partout) :

```bash
mkdir -p ~/.claude/skills
cp -r horror-beatsync-video ~/.claude/skills/
```

L'arborescence finale doit ressembler à ça — `SKILL.md` doit être **à la racine** du
dossier `horror-beatsync-video`, pas dans un sous-dossier :

```
.claude/skills/horror-beatsync-video/
├── SKILL.md
├── INSTALL.md
└── references/
    └── scripts-horror.md
```

## 2. Vérifier que Claude le voit

Relance Claude Code (le catalogue de skills est lu au démarrage), puis :

```
/horror-beatsync-video
```

Le skill doit apparaître dans l'autocomplétion. Sinon : vérifie que le chemin est bien
`.claude/skills/` (et pas `.claude/skill/`), et que `SKILL.md` contient toujours son
en-tête `---` en première ligne.

## 3. Ce qu'il te faut à côté

Le skill pilote des outils, il ne les remplace pas :

| Outil | Pourquoi | Obligatoire ? |
|---|---|---|
| `ffmpeg` / `ffprobe` | tout le montage, le mix et les mesures | **oui** |
| `node` | recalcul de la grille de beats si tu changes de fps | **oui** |
| HyperFrames | seulement pour la variante « compo authorée » (§4) | non |
| Un TTS (WaveSpeed, ElevenLabs…) | seulement si tu veux une voix générée plutôt qu'un rush | non |

Vérifie en une commande :

```bash
ffmpeg -version >/dev/null && ffprobe -version >/dev/null && node -v && echo "OK"
```

## 4. Premier montage en 3 minutes

1. Filme un rush vertical avec ta voix (ou prends un rush existant), nomme-le `rush.mp4`.
2. Dans Claude Code : `monte rush.mp4 sur la trend horror avec le script 3`.
3. Le skill télécharge le son, nettoie la pochette, cale les cuts sur les mini-drops,
   duck la musique sous la voix et sort `output_beatsync.mp4` en 1080×1920.

**Ne saute pas la dernière étape de la checklist** : sur TikTok/Instagram, il faut
rajouter le son officiel dans l'app à 1-5 % de volume par-dessus ta vidéo. C'est ce qui
te fait exister dans la trend — la bande-son mixée reste celle de ta vidéo.

## 5. L'adapter à un autre son

La grille livrée (drop 2,34s, période 8,02s, beat 0,50125s) est **mesurée sur ce
morceau précis**. Pour un autre son, ne recopie pas ces chiffres : la §2 du `SKILL.md`
explique la méthode de mesure (enveloppe RMS par trames de 20ms, front de montée le plus
raide autour de chaque drop supposé) et le one-liner Node qui recalcule la période de
pulse et le décalage de phase pour ton fps.

---

Une question, un montage qui sonne « à côté » ? Réponds directement à l'email de
livraison — c'est Tony au bout.
